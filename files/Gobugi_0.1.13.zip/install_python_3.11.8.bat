@echo off
echo Installing Python 3.11.8...

:: Step 1 - Download the Python installer
SET PYTHON_INSTALLER=python-3.11.8-amd64.exe
SET DOWNLOAD_URL=https://www.python.org/ftp/python/3.11.8/%PYTHON_INSTALLER%

echo Downloading installer from: %DOWNLOAD_URL%
powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%PYTHON_INSTALLER%'"

:: Step 2 - Install silently with PATH added
echo Installing Python 3.11.8 silently...
%PYTHON_INSTALLER% /quiet InstallAllUsers=1 PrependPath=1 Include_test=0

:: Step 3 - Clean up
del %PYTHON_INSTALLER%

:: Step 4 - Confirm installation
python --version
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python installation failed.
    pause
    exit /b 1
) ELSE (
    echo [OK] Python installed successfully.
)

exit /b 0
