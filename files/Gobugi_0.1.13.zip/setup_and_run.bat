@echo off
title Turtle Trading Bot - Installer and Runner

:: Automatically request administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator access...
    powershell -Command "Start-Process '%~f0' -Verb runAs"
    exit /b
)

echo ===========================================
echo    Turtle Trading Bot - Setup & Launch
echo ===========================================
echo.

cd /d %~dp0

:: Check required files
IF NOT EXIST run_turtle_bot.py (
    echo ERROR: run_turtle_bot.py not found.
    pause
    exit /b 1
)

IF NOT EXIST requirements.txt (
    echo ERROR: requirements.txt not found.
    pause
    exit /b 1
)

:: Check Python installation
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo Python is not installed or not in PATH.
    echo Installing Python 3.11.8 automatically...

    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe' -OutFile 'python-installer.exe'"
    start /wait python-installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0

    del python-installer.exe

    echo Please restart this script after installation is complete.
    pause
    exit /b 1
)

:: Create virtual environment
IF NOT EXIST venv (
    echo [1/4] Creating virtual environment...
    python -m venv venv
    IF %ERRORLEVEL% NEQ 0 (
        echo ERROR: Failed to create virtual environment.
        pause
        exit /b 1
    )
) ELSE (
    echo [1/4] Using existing virtual environment.
)

:: Activate virtual environment
echo.
echo [2/4] Activating virtual environment...
call venv\Scripts\activate
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to activate virtual environment.
    pause
    exit /b 1
)

:: Upgrade pip, setuptools, wheel
echo.
echo [2.5/4] Upgrading pip, setuptools, wheel...
python -m pip install --upgrade pip setuptools wheel
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to upgrade pip/setuptools/wheel.
    pause
    exit /b 1
)

:: Install dependencies
echo.
echo [3/4] Installing dependencies...
pip install -r requirements.txt
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to install required packages.
    pause
    exit /b 1
)

:: Run the app
echo.
echo [4/4] Launching Turtle Trading Bot...
echo The browser will open automatically.
echo.

streamlit run run_turtle_bot.py
SET EXIT_CODE=%ERRORLEVEL%

IF %EXIT_CODE% NEQ 0 (
    echo ERROR: Application error occurred.
    echo Error code: %EXIT_CODE%
)

pause
exit /b %EXIT_CODE%
