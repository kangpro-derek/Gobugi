@echo off
title Turtle Trading Bot
echo ======================================
echo Starting Turtle Trading Bot
echo ======================================
echo.

cd /d %~dp0

IF NOT EXIST venv (
    echo ERROR: Virtual environment not found.
    echo Please run setup_and_run.bat first to install.
    pause
    exit /b 1
)

echo Activating virtual environment...
call venv\Scripts\activate
IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to activate virtual environment.
    pause
    exit /b 1
)

echo Starting Turtle Trading Bot...
echo.
echo The web browser will open automatically.
echo Do not close this window while using the bot.
echo.

streamlit run run_turtle_bot.py

echo.
echo Bot has been closed.
echo Thank you for using Turtle Trading Bot.
pause